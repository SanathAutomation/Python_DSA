#sent = "I love my India"

def sorting (A) :
    for i in range(len(A)-1) :
        for j in range(i , len(A)) :
            if A[i] > A[j] :
                temp = A[i]
                A[i] = A[j]
                A[j] = temp

    return A

if __name__=='__main__' :
    A = [1,4,2,6,3,8]
    print(sorting(A))







