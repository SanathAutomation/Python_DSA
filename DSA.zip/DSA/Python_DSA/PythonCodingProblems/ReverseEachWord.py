str = "the sky is blue"

# blue is sky the

words = str.split(" ")

rev = [word[::-1] for word in words]
print(rev)

revword = " ".join(rev)
print(revword)


