def panagram (A) :
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    for i in alphabet :
        if i not in A.lower() :
            print("not pan")
            return

    print("pan")

if __name__=='__main__' :
    A = "The quick brown fox jumps over the lazy dog"
    panagram(A)