#
# n1 = 0
# n2 = 1
#
# print(n1)
# print(n2)
#  #1
#
# for i in range (2,10):
#     sum = n1 + n2
#     print(sum)
#
#     n1 = n2
#     n2 = sum


def fibonacci(n):
    if(n <= 1):
        return n
    else:
        return(fibonacci(n-1) + fibonacci(n-2))
n = int(input("Enter number of terms:"))
print("Fibonacci sequence:")
for i in range(n):
    print(fibonacci(i))