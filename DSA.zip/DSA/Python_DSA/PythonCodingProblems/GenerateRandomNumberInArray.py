from random import randrange

def swap (A , i, j):
    temp = A[i]
    A[i] = A[j]
    A[j] = temp


def findRandom(A):
    for i in reversed(range(1, len(A))):
        j = randrange(i+1)
        swap(A, i,j)
if __name__=='__main__':
    A = [2,4,1,7,9]

    findRandom(A)

    print(A)

