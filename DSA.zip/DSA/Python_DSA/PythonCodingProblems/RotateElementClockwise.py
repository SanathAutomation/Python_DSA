def rotateElement (A , num) :
    output_List = []
    for i in range(len(A)-num , len(A)) :
        output_List.append(A[i])
    for i in range(len(A)-num):
        output_List.append(A[i])

    return output_List

if __name__=='__main__':
    A = [2,4,5,6,7,8,9]
    num = 2
    print(rotateElement(A,num))
