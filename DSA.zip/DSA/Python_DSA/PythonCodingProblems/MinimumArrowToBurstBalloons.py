def minArrowToBurstBalloons (A) :
    #sort using end position of the balloons using lambda function
    A = sorted(A , key= lambda x:x[1])
    end = A[0][1]
    arrow = 1
    for i in range(1 , len(A)):
        # If the start of ith balloon <= end than do nothing
        if A[i][0] <= end :
            continue
        else:
        # if start of the next balloon >= end of the first balloon then increment the arrow
            end = A[i][1]
            arrow += 1
    return arrow



if __name__=='__main__':
    A = [[2,6],[5,9],[0,3],[8,11],[14,18],[4,5]]
    print(minArrowToBurstBalloons(A))