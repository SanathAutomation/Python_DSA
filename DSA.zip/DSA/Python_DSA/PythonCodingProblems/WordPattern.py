def wordPattern(pattern , A) :
    if pattern == None or A == None :
        return False

    len_str = len(A.split(" "))
    len_pattern = len(pattern)

    if len_str != len_pattern :
        return False

    word = A.split(" ")
    d = {}
    for i in range(len(pattern)):
        s = word[i]
        p = pattern[i]
        if p in d :
            if d[p] != s :
                return False
        else:
            if s in d.values():
                return False
            d[p] = s
    return True


if __name__=='__main__':
    pattern = "abba"
    A = "dog cat cat dog"
    print(wordPattern(pattern,A))

