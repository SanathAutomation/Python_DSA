myList = [2,4,2,6,7,2,9]

num = 2
count = 0

for ele in myList:
    if (ele == num):
        count += 1
print("{} occured {} times".format(num,count))
