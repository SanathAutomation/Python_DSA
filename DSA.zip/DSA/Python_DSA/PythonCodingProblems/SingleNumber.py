# Find the single number in a list which has only one occurance in the list

def singleNumber (A) :
    d = {}
    for i in A :
        try:
            d.pop(i)
        except :
            d[i] = 1
    return d.popitem()[0]

if __name__=='__main__' :
    A = [2,4,6,4,2]
    print(singleNumber(A))