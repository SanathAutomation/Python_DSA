def pageCount (n,p) :
    if n % 2 == 0 :
        n += 1

    front , back = None , None
    front = p//2

    back = (n-p)//2

    if front < back :
        return front
    else:
        return back


if __name__=='__main__' :
    n = 10
    p = 6
    print(pageCount(n,p))

