arr = [2,4,7,9,1]

num = 8
flag = 0

for i in arr:
    if (i == num):
        flag = 1
        print("Ele present")
        break


if (flag==0):
    print("Ele not present")