#duplicates
from collections import Counter
def findCommonChar(X,Y):
    dict1 = Counter(X)
    dict2 = Counter(Y)
    inter_dict = dict1 & dict2
    if len(inter_dict) == 0 :
        exit(-1)
        return
    common_char = list(inter_dict.elements())
    finalchar = sorted(common_char)
    print(''.join(finalchar))


if __name__=='__main__':
    X = "sanath"
    Y = "sanh"
    findCommonChar(X,Y)



