#Isomorphic strings are 2 strings which are identical meaning characters can be replaced from 1st string to make it 2nd String.

def isIsomorphic(str1, str2):
    # Create an empty dictionary to store mappings between characters
    char_map = {}

    # Check if the two strings have the same length
    if len(str1) != len(str2):
        return False

        # Loop through each character in the strings
    for i in range(len(str1)):

        # If the current character in str1 has not been mapped yet
        if str1[i] not in char_map:
            # Check if the current character in str2
            # has been mapped to a different character

            if str2[i] in char_map.values():
                return False
                # Add a new mapping between the characters
            char_map[str1[i]] = str2[i]

            # If the current character in str1 has already been mapped
        else:
            # Check if the mapping is consistent with
            # the current character in str2
            if char_map[str1[i]] != str2[i]:
                return False

                # If we made it through the loop without finding any inconsistencies,
    # the strings are isomorphic
    return True

if __name__=='__main__' :
    str1 = "aabck"
    str2 = "xxygf"
    if isIsomorphic(str1, str2):
        print("The two strings are isomorphic.")
    else:
        print("The two strings are not isomorphic.")



