#find the max diff between 2 integers where smaller number should appear before large number
import sys
def findMaxDiff(A):
    if not A or len(A) == 0 :
        return -1
    max_value = -sys.maxsize

    for i in range(0, len(A)-1):
        for j in range(i+1 , len(A)):
            if A[j] > A[i] :
                max_value = max(max_value, A[j] - A[i])
        return max_value
    if max_value != -sys.maxsize :
        return max_value
    else:
        return -1

if __name__=='__main__':
    A = [1, 7, 9, 5, -1, 3, 5]
    value = findMaxDiff(A)
    if value != -1:
        print(value)
    else:
        print("Not found")

