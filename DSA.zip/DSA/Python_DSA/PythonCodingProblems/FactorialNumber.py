
fact = 1
num = 5

# if num < 0:
#     print("Fact doesn't exist")
# elif num == 0:
#     print("Fact is 1")
# else:
#     for i in range(1, num+1):
#         fact = fact* i
#     print("Fact of ", num , " is ", fact)


def factorial (num):
        if (num==0 or num==1):
            return 1
        else:
            return num * factorial(num-1)

num = 5
print("Factorial of " , num , " is " , factorial(num))


