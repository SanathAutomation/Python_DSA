def findduplicates(A):
    duplicate = []
    uniqueNum = []

    for i in A :
        if i not in duplicate:
            duplicate.append(i)
        elif i not in uniqueNum:
            uniqueNum.append(i)

    print(uniqueNum)

if __name__=='__main__':
    A = [2,4,7,1,8,4]
    findduplicates(A)
