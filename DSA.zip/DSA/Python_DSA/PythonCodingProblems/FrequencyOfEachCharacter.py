stri = "sanath chakraborty"

ch = {}

for i in stri:
    if i in ch:
        ch[i] += 1
    else:
        ch[i] = 1

print("Freq of each char is " , str(ch))
