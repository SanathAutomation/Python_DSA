
# You will be given a list of integers, , and a single integer . You must create an array of length  from elements of  such that its unfairness is minimized. Call that array . Unfairness of an array is calculated as
#
# Where:
# - max denotes the largest integer in
# - min denotes the smallest integer in


import sys


def minUnfairness (k , arr) :
    arr.sort()
    min_value = sys.maxsize

    for i in range(len(arr) -k + 1) : #0,1,2
        current_value = arr[i+k-1] - arr[i] # 1 , 0       2,1       3,2

        min_value = min(min_value , current_value)

    return min_value

if __name__=='__main__' :
    arr = [1,7,9,3,8,4,2]
    k = 2
    print(minUnfairness(k , arr))




