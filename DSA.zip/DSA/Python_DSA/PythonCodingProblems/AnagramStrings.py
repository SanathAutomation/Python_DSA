def findAnagram(X , Y) :

    if (sorted(X) == sorted(Y)):
        print("Anagram")
    else:
        print("Not Anagram")

if __name__=='__main__':
    X = "silent"
    Y = "listent"
    findAnagram(X,Y)