
'''
You are a professional robber planning to rob houses along a street. Each house has a certain amount of money stashed, the only constraint stopping you from robbing each of them is that adjacent houses have security system connected and it will automatically contact the police if two adjacent houses were broken into on the same night.

Given a list of non-negative integers representing the amount of money of each house, determine the maximum amount of money you can rob tonight without alerting the police.
'''

def rob(nums) :
    n = len(nums)
    dp = [0] * (n + 1)
    print(dp)

    dp[0] = 0
    dp[1] = nums[0]  # for house 0, dp index starts from 1

    for i in range(1, n):
        include_cur_house = nums[i] + dp[i - 1]
        exclude_cur_house = dp[i]
        dp[i + 1] = max(include_cur_house, exclude_cur_house)

    return dp[n]

if __name__=='__main__':
    arr = [1,3,2,1,5,2]
    print(rob(arr))