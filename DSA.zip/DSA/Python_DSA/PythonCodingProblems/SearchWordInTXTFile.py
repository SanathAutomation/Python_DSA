def searchWord(filePath, word) :
    with open(filePath,'r')as file :
        content = file.read()

        if word in content :
            print("Word is present")
        else:
            print("Word is not present")

if __name__=='__main__' :
    filepath = r'C/Drive/location/file.txt'
    word = "sanath"
    searchWord(filepath,word)

