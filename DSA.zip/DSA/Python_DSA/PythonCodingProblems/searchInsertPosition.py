# Search Insert position of an element in a sorted array

def searchInsertPosition(A,k) :
    n = len(A)
    for i in range(n-1) :
        if A[i] == k :
            return i
        elif A[i] > k :
            return i
    return n

if __name__=='__main__':
    A = [2,4,6,9]
    k = 10
    print(searchInsertPosition(A,k))
