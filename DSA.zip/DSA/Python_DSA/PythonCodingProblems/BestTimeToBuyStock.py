
def bestTimeToBuyAndSellStock (A) :
    left =0
    profit = 0
    for i in range(1 , len(A)):
        if A[left] < A[i] :
            profit = max(profit , A[i]-A[left])
        else:
            left = i
    return profit





if __name__=='__main__':
    A = [7,1,5,3,6,4]
    print(bestTimeToBuyAndSellStock(A))

