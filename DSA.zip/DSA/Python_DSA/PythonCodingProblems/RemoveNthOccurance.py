myList = ["Geeks" ,"for" , "Geeks"]
word = "Geeks"
n = 1
count = 0

for i in range(0,len(myList)-1):
    if (myList[i] == word):
        count += 1
        if (count == n):
            del myList[i]

print(myList)


