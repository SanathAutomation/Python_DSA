#Find the difference of 2 strings

def findDiff(A,B):
    sum = 0

    for i in A :
        sum += ord(i)

    for i in B :
        sum -= ord(i)

    return chr(sum)

if __name__=='__main__':
    A = "sanath"
    B = "sanat"
    print(findDiff(A,B))

