def findSubArray(A):

    for i in range(len(A)):
        target = 0
        for j in range(i , len(A)):
            target += A[j]
            if target == 0:
                print("Subarray is " , (i,j))

if __name__=='__main__':
    A = [3, 4, -7, 3, 1, 3, 1, -4, -2, -2]
    findSubArray(A)