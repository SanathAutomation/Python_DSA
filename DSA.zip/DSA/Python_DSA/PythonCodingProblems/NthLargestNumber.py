mylist = [2,4,7,9,1]

mylist.sort()

print("Largest is " , mylist[-1])
print("Second Largest is " , mylist[-2])