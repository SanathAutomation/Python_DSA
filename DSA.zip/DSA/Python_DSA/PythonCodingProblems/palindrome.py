str = input("Enter a string : ")

check = str[::-1]

if (str == check):
    print("Palindrome")
else:
    print("Not Palindrome")