
mylist = [2, 4, -6, -2, 6, 3, -3, -4]
#total = 0


def findlist(listItem):
    for i in range(0, len(listItem)):

        total = 0
        for j in range(i , len(listItem)):

            total += listItem[j]
            if total == 0:
                print("Sublist is from : " , (i,j))


if __name__=="__main__":


    findlist(mylist)

