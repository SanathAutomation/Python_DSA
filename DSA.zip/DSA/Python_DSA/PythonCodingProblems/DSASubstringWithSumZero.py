#substring whose sum is zero

def substr(A):
    for i in range(0 , len(A)):
        total = 0
        for j in range(i , len(A)):
            total += A[j]

            if total == 0:
                print("Substring ranges from " , (i,j))

if __name__=='__main__':
    A = [2,-3,1,-2]
    substr(A)