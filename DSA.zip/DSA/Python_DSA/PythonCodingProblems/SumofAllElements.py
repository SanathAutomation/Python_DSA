arr=[2,4,7,9]
num = sum(arr)
print(num)
print(sum(arr,10))
print(sum(arr,-10))

