def findSmallestMissingNum (A,left = None , right = None) :
    if left is None and right is None :
        left, right = 0, len(A) - 1

    if left > right :
        return left

    mid = (left + right) // 2
    if A[mid] == mid:
        return findSmallestMissingNum(A, mid + 1, right)
    else:
        return findSmallestMissingNum(A, left, mid - 1)



if __name__=='__main__' :
    A = [0,1,2,4,5,6,7]
    print(findSmallestMissingNum(A))

