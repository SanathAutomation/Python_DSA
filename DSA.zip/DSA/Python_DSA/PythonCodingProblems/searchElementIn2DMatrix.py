# search element in sorted matrix

def searchElementInMatrix(mat , target) :
    row = 0
    col = len(mat[row])-1
    while (row < len(mat) and col >=0) :
        if (mat[row][col] == target) :
            return [row,col]

        if mat[row][col] < target :
            row += 1

        else:
            col -= 1

    return [-1,-1]

if __name__=='__main__':
    mat = [
        [2,4,7],
        [8,9,10],
        [11,13,45]
    ]
    target = 13
    print(searchElementInMatrix(mat,target))

