def firstDigit (n) :
    while n >= 10 :
        n = n / 10
    return int(n)

def lastDigit(n) :
    return n%10

if __name__=='__main__' :
    n = 1234
    print(firstDigit(n))
    print(lastDigit(n))

