

def addNumbers(mat , x,y):
    total = 0

    for i in range(x + 1):
        for j in range(y+1):
            total += mat[i][j]
    return total

if __name__=='__main__':
    mat = [
        [1,2,3],
        [4,5,6],
        [7,8,9]
    ]
    x = 2
    y = 2
    value = addNumbers(mat,x,y)
    print(value)
