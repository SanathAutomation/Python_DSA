def removeDuplicates(A) :
    n = len(A)
    if n == 0 or n == 1 :
        return n
    j = 0
    for i in range(n-1) :
        if A[i] != A[i+1] :
            A[j] = A[i]
            j += 1
    A[j] = A[n-1]
    return j+1

if __name__=='__main__':
    A = [1,3,3,4,5,6,7,7,8,8,9]
    new = removeDuplicates(A)
    for i in range(new):
        print(A[i] , end= " ")