def findrepeatedInt(a, b ,c) :
    repeated = [i for i in a if i in b if i in c]
    print(repeated)

if __name__=='__main__' :
    a = [2,3,5,8,9]
    b = [2,4,8,9,11]
    c = [1,8,11]
    findrepeatedInt(a,b,c)