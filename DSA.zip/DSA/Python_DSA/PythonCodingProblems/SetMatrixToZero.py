def setMatrixToZeros (mat) :
    if not mat or len(mat) == 0 :
        pass
    elif len(mat) == 1 or len(mat[0]) == 1 :
        pass
    else :
        rows_with_0 = [False] * len(mat)
        col_with_0 = [False] * len(mat[0])

        for i in range(len(mat)):
            for j in range(len(mat[0])):
                if mat[i][j] == 0:
                    rows_with_0[i] = True
                    col_with_0[j] = True

        for i in range(len(mat)):
            for j in range(len(mat[0])):
                if rows_with_0[i] or col_with_0[j]:
                    mat[i][j] = 0
        return mat


if __name__=='__main__':
    mat = [
        [1,1,1],
        [1,0,1],
        [1,1,1]
    ]
    print(setMatrixToZeros(mat))
