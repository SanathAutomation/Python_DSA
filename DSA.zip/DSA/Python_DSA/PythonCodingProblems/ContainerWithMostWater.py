def containerWithMostWater (A):
    if not A or len(A) == 0 :
        return 0
    area = 0
    for i in range(len(A)) :
        for j in range(i+1 , len(A)) :
            area = max(area , min(A[i] , A[j]) * (j-i) )
    return area

if __name__=='__main__':
    A = [2,4,6,8]
    print(containerWithMostWater(A))
