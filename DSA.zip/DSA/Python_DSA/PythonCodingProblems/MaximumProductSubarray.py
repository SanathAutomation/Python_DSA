def findMaxProductSubarray (A) :
    min_P = max_P = A[0]
    maximum_Product = max_P

    for i in A[1:] :
        temp = min_P
        min_P = min(i , i*min_P , i*max_P)
        max_P = max(i , i*temp , i*max_P)
        maximum_Product = max(max_P , maximum_Product)
    return maximum_Product

if __name__=='__main__' :
    A = [2,4,6,-4,8,2]
    print(findMaxProductSubarray(A))
