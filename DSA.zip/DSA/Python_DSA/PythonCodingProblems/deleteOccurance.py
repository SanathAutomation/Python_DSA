# def removeOccurance (A , c) :
#     print(A.replace(c , ""))
#
# if __name__=='__main__' :
#     A = "hello world"
#     c = "o"
#     removeOccurance(A,c)

def deleteOccuranceInList (A,c) :
    res = [i for i in A if i != c]
    return res

if __name__=='__main__' :
    A = [1,3,1,5,5,1,1]
    n = 1
    print(deleteOccuranceInList(A,n))
