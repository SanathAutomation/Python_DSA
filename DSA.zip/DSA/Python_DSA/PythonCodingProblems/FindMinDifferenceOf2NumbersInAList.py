def minDiffOf2Num(A) :
    n = len(A)
    if n <=1 :
        return
    A.sort()
    min_diff = A[1] - A[0]
    for i in range(2,n) :
        min_diff = min(min_diff , A[i] - A[i-1])

    for i in range(1,n) :
        if A[i] - A[i-1] == min_diff :
            print("(",A[i-1] , A[i],")")


if __name__=='__main__' :
    A = [10,12,4,7,34,38,45]
    minDiffOf2Num(A)

