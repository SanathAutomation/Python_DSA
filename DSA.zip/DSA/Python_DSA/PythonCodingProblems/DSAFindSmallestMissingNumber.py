#Find Smallest Missing number

def findSmallest(A , left = None , right = None):

    if left is None and right is None:
        (left,right) = (0, len(A)-1)
    if left > right:
        return left
    mid = left + (right-left) //2

    if A[mid] == mid :
        return findSmallest(A , mid+1 , right)
    else:
        return findSmallest(A , left , mid-1)
if __name__=='__main__':
    A = [0,1,2,3,4,6]
    req = findSmallest(A)
    print(req)
