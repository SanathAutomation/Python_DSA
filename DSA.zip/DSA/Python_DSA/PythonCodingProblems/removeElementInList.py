def removeElement (A, val) :
    if not A or len(A) ==0:
        return 0
    new_listA = set(A)
    new_listA.discard(val)
    print(new_listA)
    value = list(new_listA)
    print(value)

    # A.remove(val)
    # return A



if __name__=='__main__':
    A = [2,4,4,5,7]
    val = 5
    removeElement(A,val)
