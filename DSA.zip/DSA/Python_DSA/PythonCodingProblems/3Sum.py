# 3Sum refers to the set of 3 distinct numbers whose sum is 0 in an array

def threeSum (A) :
    ret = []
    A.sort()
    for i in range(len(A)) :
        if i != 0 and A[i] == A[i-1] :
            continue

        l = i+1
        r = len(A) -1
        while l < r :
            total = A[i] + A[l] + A[r]
            if total > 0 :
                r -= 1

            elif total < 0 :
                l += 1
            else:
                ret.append([A[i] , A[l] , A[r]])
                l += 1
                while l < r and A[l] == A[l-1] :
                    l += 1

    return ret

if __name__=='__main__' :
    A = [-12,5,5,6,6]
    print(threeSum(A))




