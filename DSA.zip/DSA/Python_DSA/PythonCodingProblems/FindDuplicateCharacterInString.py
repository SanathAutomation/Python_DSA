def findDuplicateCharactersInString (st) :
    x = []
    for i in st :
        if i not in x and st.count(i) > 1 :
            x.append(i)

    print(''.join(x))


if __name__=='__main__' :
    A = "sanath"
    findDuplicateCharactersInString(A)


