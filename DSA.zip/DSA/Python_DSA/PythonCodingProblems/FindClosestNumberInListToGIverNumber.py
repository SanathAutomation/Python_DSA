
import heapq


def findANumberClosestToAGiverNumberInList (A , K) :
    return heapq.nsmallest(1 , A , key= lambda x : abs(x-K))[0]


if __name__=='__main__' :
    A = [1,3,6,9,12,2,-4,-11]
    k = -2
    print(findANumberClosestToAGiverNumberInList(A,k))
