def findPair(A, target):
    low , high = 0, len(A)-1
    A.sort()
    while low < high:
        if A[low] + A[high] == target:
            print("Pair is " , A[low], A[high])
            return
        elif A[low] + A[high] < target:
            low += 1
        else:
            high -= 1
    print("Pair not found")

if __name__=='__main__':
    A = [2,4,5,7,9]
    target = 12
    findPair(A,target)


