def findFirstrepeatingElement (A) :
    num = set()
    for i in A :
        if i in num :
            return i
        num.add(i)

    return None

if __name__=='__main__' :
    A = ["sana" , "mohan" , "rohan" , "sana" , "rohan"]
    print(findFirstrepeatingElement(A))