
def removeDuplicateCharInString(A) :
    char = []
    prev = None

    for c in A :
        if prev != c :
            char.append(c)
            prev = c

    return "".join(char)

    '''
    char = []
    for i in A :
        if i not in char :
            char.append(i)

    return "".join(char)
    '''

if __name__=='__main__':
    A = "AABBBBCDDDDEE"
    print(removeDuplicateCharInString(A))

