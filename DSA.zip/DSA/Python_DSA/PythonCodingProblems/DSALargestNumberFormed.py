from functools import cmp_to_key

@cmp_to_key
def compare(a,b):

    values1 = str(a) + str(b)
    values2 = str(b) + str(a)

    if (values1 > values2):
        return -1
    elif values2 > values1 :
        return 1
    else:
        return 0

def largeNum(num):
    num.sort(key=compare)
    return ''.join(map(str,num))


if __name__=='__main__':
    num = [34,23,67,98,59]
    reqnum = largeNum(num)
    print(reqnum)
