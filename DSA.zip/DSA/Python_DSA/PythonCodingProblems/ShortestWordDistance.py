import sys


def shortestWordDist (word , word1 , word2) :
    if word1 not in word or word2 not in word :
        return -1

    min_dist = sys.maxsize
    indx1 = -1
    indx2 = -1

    for i in range(len(word)) :
        if word[i] == word1 :
            indx1 = i

        if word[i] == word2 :
            indx2 = i
    if indx1 != -1 and indx2 != -1 :
        min_dist = min(min_dist, abs(indx2 - indx1))



    return min_dist

if __name__=='__main__' :
    words = ["practice", "makes", "perfect", "coding", "makes"]
    word1 = "makes"
    word2 = "coding"
    print(shortestWordDist(words, word1,word2))