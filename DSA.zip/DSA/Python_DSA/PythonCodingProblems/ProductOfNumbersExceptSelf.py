def findProductOfNumbers (A) :
    output = [1]
    for i in range(len(A)-1 ,0,-1) :
        output.append(output[-1] * A[i])
    output = output[::-1]
    left = 1
    for i in range(len(A)) :
        output[i] = output[i] * left
        left *= A[i]

    return output

if __name__=='__main__' :
    A = [1,2,3]
    print(findProductOfNumbers(A))

    # 0(n)
