def findIndexOf1stOccurance (A , target) :
    if not A or len(A) == 0 :
        return 0
    m = len(A)
    n = len(target)

    for i in range(m-n+1) :
        if A[i:n+i] == target :
            return i
    return -1

if __name__=='__main__' :
    A = "sadbutsadbutnot"
    target = "but"
    print(findIndexOf1stOccurance(A,target))



