def mejorityElement (A) :
    count = 0
    majority = 0
    for i in A :
        if count == 0 :
            majority = i
        if majority == i :
            count += 1
        else:
            count -= 1
    return majority

if __name__=='__main__':
    A = [2,2,1,1,1,2,2]
    print(mejorityElement(A))
