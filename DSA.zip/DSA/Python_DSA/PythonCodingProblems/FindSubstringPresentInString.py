str = "welcome to python world"

substring = "python1"

if (str.find(substring) != -1):
    print("Present")
else:
    print("Not present")