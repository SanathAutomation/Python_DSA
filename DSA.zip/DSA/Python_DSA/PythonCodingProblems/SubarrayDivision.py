def birthday(s , m , d) :
    ways = [sum(s[i:i+m]) for i in range(len(s)-m+1)]
    print(ways.count(d))

if __name__=='__main__' :
    s = [2,2,1,3,2]
    m = 2
    d = 4

    birthday(s,m,d)