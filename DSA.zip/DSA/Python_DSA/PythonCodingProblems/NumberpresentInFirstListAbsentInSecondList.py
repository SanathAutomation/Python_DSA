def findnewList (A,B) :
    s = dict()
    for i in range(len(B)) :
        s[B[i]] = 1

    for i in range(len(A)) :
        if A[i] not in s.keys() :
            print(A[i] , end=" ")

if __name__=='__main__' :
    A = [1, 2, 6, 3, 4, 5]
    B = [2, 4, 3, 1, 0]
    findnewList(A,B)

