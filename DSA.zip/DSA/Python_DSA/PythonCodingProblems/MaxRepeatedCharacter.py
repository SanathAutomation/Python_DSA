str = "sanathchakraborty"

ch = {}

for i in str:
    if i in ch:
        ch[i] += 1
    else:
        ch[i] = 1

maxchar = max(ch , key= ch.get)
print(maxchar)