import ipaddress

def get_newIP(currentIP) :
    ip = ipaddress.IPv4Address(currentIP)

    for i in range(10) :
        newip = ip+i+1

        print(newip)

    #return next


if __name__=='__main__' :
    current_ip = "10.255.255.1"
    get_newIP(current_ip)
