
#using hashing in maps

def findPair(A , target) :
    d = {}

    for i , e in enumerate(A) :
        if target - e in d :
            print("Pair is " , A[d.get(target-e)] , A[i])
            return
        d[e] = i
    print("Not found")


if __name__=='__main__' :
    A = [2,1,6,3,9]
    target = 10
    findPair(A , target)
