def mergeSortedArray(arr1 , arr2 , m , n , arr3) :
    i =0
    j = 0
    k = 0

    while (i < m) :
        arr3[k] = arr1[i]
        k += 1
        i += 1

    while (j < n):
        arr3[k] = arr2[j]
        k += 1
        j += 1

    arr3.sort()


if __name__=='__main__':
    arr1 = [1,4,6]
    m = len(arr1)

    arr2 = [2,3,6,7,9]
    n = len(arr2)

    arr3 = [0 for i in range(m+n)]
    mergeSortedArray(arr1 , arr2 , m , n , arr3)

    print("Arrays after merging")
    for i in range(m+n) :
        print(arr3[i] , end=" ")


