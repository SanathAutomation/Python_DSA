
num = int(input("Enter a num : "))
count = 0
if num>1:
    for i in range(1,num+1):
        if num%i == 0:
            count += 1
    if (count == 2):
        print("Num is prime")
    else:
        print("Num is not prime")



