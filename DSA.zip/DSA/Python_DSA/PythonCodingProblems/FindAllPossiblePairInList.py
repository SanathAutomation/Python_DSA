def findPossiblePair (A) :
    res = [(a,b) for idx , a in enumerate(A) for b in A[idx + 1:] ]
    return str(res)

if __name__=='__main__' :
    A = [1,2,4,5]
    print(findPossiblePair(A))
    