from bisect import bisect_left, bisect_right


def findFirstAndLastPosition (nums ,target) :
    l = bisect_left(nums, target)
    if l == len(nums) or nums[l] != target:
        return -1, -1
    r = bisect_right(nums, target) - 1
    return l, r


if __name__=='__main__' :
    A = [2,4,6,7,7,7,8,9]
    target = 7
    print(findFirstAndLastPosition(A,target))
