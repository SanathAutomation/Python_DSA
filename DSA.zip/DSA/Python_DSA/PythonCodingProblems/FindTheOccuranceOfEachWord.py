def findOccurance(A) :
    word = A.split(" ")
    ch = {}
    for i in word :
        if i in ch :
            ch[i] += 1
        else:
            ch[i] = 1

    return str(ch)

if __name__=='__main__' :
    A = "I love python as python is good for love"
    print(findOccurance(A))
