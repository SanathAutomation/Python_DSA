def minMaxSum (arr) :
    arr.sort()
    min_value = sum(arr) - arr[len(arr)-1]
    max_value = sum(arr) - arr[0]
    print(min_value,max_value)

if __name__=='__main__' :
    arr = [1,3,5,7,9]
    minMaxSum(arr)