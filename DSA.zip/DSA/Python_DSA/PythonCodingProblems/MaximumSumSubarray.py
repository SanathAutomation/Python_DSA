#find the max sum in a substring by adding the numbers

def findMax(A):
    a = 0
    b = 0

    for i in A :
        a = a+i

        a = max(a, 0)
        b = max(a,b)
    return b
if __name__=='__main__':
    A = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
    print(findMax(A))