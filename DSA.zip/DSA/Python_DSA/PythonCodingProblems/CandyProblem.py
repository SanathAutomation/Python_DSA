def candyProblem (arr , n) :
    sum = 0
    answer = [1] *n

    if n == 1 :
        return n
    for i in range(n-1):
        if arr[i+1] > arr[i] :
            answer[i+1] = answer[i] +1

    for i in range(n-2 , -1 , -1):
        if arr[i] > arr[i+1] and answer[i] <= answer[i+1] :
            answer[i] = answer[i+1] +1
        sum += answer[i]

    sum += answer[n-1]
    return sum

if __name__=='__main__':
    A = [1,2,2]
    n = len(A)
    print(candyProblem(A,n))
