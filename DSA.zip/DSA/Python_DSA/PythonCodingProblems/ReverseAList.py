myList = [2,4,5,7,9]

# print(myList[::-1])


str = "sanath"

print(str[::-1])