def uniqueChars(string):
    # Converting to a set and comparing the size takes O(N)
    # O(N) is the time complexity required to convert iterable to a set
    return len(set(string)) == len(string)

def bruteSolution(string : str) -> str:

    size = len(string)
    max_len = 0
    result_string = ""
    # Creating substrings

    for i in range(size):
        for j in range(i, size):
            # A substring is from i - j
            # String Slicing is also an O(M) complexity where M is substring size
            substring = string[i : j+1]

            if uniqueChars(substring):
                # substring contains only unique characters
                if(len(substring) > max_len):
                    result_string = substring
                    max_len = len(substring)

    print(result_string, max_len)


if __name__=='__main__' :
    A = "ABCDEFGABCD"
    bruteSolution(A)