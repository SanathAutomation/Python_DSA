import sys
myList1 = [2,6,-4,3,-5,-8,9]

def maxPro(lis):
    max_value = -sys.maxsize

    for i in range(len(lis) -1):

        for j in range(i + 1 , len(lis)):
            if (lis[i] * lis[j] > max_value) :
                max_value = lis[i] * lis[j]
    print(max_value)
    print("Numbers are : " , lis[i] , lis[j])

if __name__=='__main__':
    maxPro(myList1)




