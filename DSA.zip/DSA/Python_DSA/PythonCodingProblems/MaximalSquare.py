def maximalSquare (mat) :
    r = len(mat)
    c = len(mat[0])

    max_lenght = 0
    dp = [[0] * c for _ in range(r)]

    for i in range(r) :
        for j in range(c) :
            if i == 0 or j == 0 or mat[i][j] == '0' :
                if mat[i][j] == '1' :
                    dp[i][j] = 1
                else :
                    dp[i][j] = 0


            else:
                dp[i][j] = min(dp[i-1][j] , dp[i-1][j-1] , dp[i][j-1]) + 1

            max_lenght = max(max_lenght , dp[i][j])

    return max_lenght * max_lenght

if __name__=='__main__' :
    mat = [["1","0","1","0","0"],["1","0","1","1","1"],["1","1","1","1","1"],["1","0","0","1","0"]]
    print(maximalSquare(mat))