def absDiff (mat , n) :
    primary = 0
    secondary = 0

    for i in range(0 , n) :
        primary += mat[i][i]
        secondary += mat[i][n-i-1]

    return abs(primary - secondary)


if __name__=='__main__' :
    mat = [
        [2,4,5],
        [1,2,3],
        [6,7,8]
    ]
    n = 3

    print(absDiff(mat , n))