def findLengthOfLastWord (A) :
    x = A.strip()
    print(x)

    l= 0
    for i in range(len(A)) :
        print(x[i])
        if x[i] == " " :
            l = 0
        else:
            l += 1

    print(l)


if __name__=='__main__':
    A = "jio pagla tu hai"
    findLengthOfLastWord(A)
