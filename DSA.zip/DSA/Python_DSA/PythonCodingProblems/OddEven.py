def getOddAndEven (A) :
    even = [num for num in A if num %2 == 0]
    odd = [num for num in A if num %2 != 0]
    return even , odd
if __name__=='__main__' :
    A = [1,3,4,5,6]
    # even , odd = getOddAndEven(A)
    # print(even)
    # print(odd)
    print(getOddAndEven(A))


