# sort without using sort keyword

mylist = [2,5,8,1,5,6]

for i in range(0, len(mylist)):
    for j in range(i+1 , len(mylist)):
        if (mylist[i] > mylist[j]):
            temp = mylist[i]
            mylist[i] = mylist[j]
            mylist[j] = temp

print(mylist)