
arr = [2,4,7,9,5]

l = len(arr)


# temp = arr[0]
# arr[0] = arr[l-1]
# arr[l-1] = temp
# print(arr)

arr[0],arr[len(arr)-1] = arr[len(arr)-1], arr[0]
print(arr)
