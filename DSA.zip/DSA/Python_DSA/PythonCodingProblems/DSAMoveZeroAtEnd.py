
def moveele(num):

    k= 0
    for i in num:
        if i:
            num[k] = i
            k += 1

    for i in range(k , len(num)):
        num[i] = 0

if __name__=='__main__':
    num = [2,0,5,6,7,0,0,1]
    moveele(num)
    print(num)