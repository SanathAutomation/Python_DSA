def findLargestWord (A) :
    s = A.split(" ")
    word = max(s,key=len)
    print(word)

if __name__=='__main__' :
    A = "ram aaam khata hai"
    findLargestWord(A)
