class Node :
    def __init__(self , key = None , left = None , right = None):
        self.key = key
        self.left = left
        self.right = right

def getHeight(root):
    if root is None:
        return 0

    return 1 + max(getHeight(root.left) , getHeight(root.right))

if __name__=='__main__':
    root = Node(20)
    root.left = Node(16)
    root.right= Node(16)
    root.left.left= Node(16)
    root.left.right= Node(16)
    root.right.left = Node(16)
    root.right.right = Node(25)

print(getHeight(root))