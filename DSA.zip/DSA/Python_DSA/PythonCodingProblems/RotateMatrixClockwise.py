def rotateMatrix (mat) :
    if not mat or len(mat) == 0 :
        return 0
    for i in range(len(mat)) :
        for c in range(i) :
            mat[i][c] , mat[c][i] = mat[c][i] , mat[i][c]

    for i in range(len(mat)):
        mat[i].reverse()

    return mat


if __name__=='__main__':
    mat = [
        [1,2,3],
        [4,5,6],
        [7,8,9]
    ]
    print(rotateMatrix(mat), end=" ")