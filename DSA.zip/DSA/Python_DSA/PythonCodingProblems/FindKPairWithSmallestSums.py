import heapq


def kSmallestPairs(nums1 , nums2 , k):
    minHeap = []

    for i in range(min(k, len(nums1))):
      heapq.heappush(minHeap, (nums1[i] + nums2[0], i, 0))

    ans = []
    while minHeap and len(ans) < k:
      _, i, j = heapq.heappop(minHeap)
      ans.append([nums1[i], nums2[j]])
      if j + 1 < len(nums2):
        heapq.heappush(minHeap, (nums1[i] + nums2[j + 1], i, j + 1))

    return ans

if __name__=='__main__' :
    A = [1,7,9]
    B = [2,4,6]
    k = 6
    print(kSmallestPairs(A, B , k))