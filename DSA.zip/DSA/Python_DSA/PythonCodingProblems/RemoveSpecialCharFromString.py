def removeSpecialChar (A) :
    rem = [i for i in A if i.isalnum() ]
    return "".join(rem)

if __name__=='__main__' :
    A = "san@a$th123!!"
    print(removeSpecialChar(A))