def findPair (arr) :
    d = {}

    for i in arr :
        if i in d :
            d[i] += 1

        else:
            d[i] = 1

    pair = 0
    for i in d :
        pair += d[i] //2

    return pair

if __name__=='__main__' :
    arr = [1,2,1,2,1,3,2]
    print(findPair(arr))

