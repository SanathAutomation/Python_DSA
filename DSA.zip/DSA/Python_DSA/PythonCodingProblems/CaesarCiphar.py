
import string
symbol_low = string.ascii_lowercase
symbol_high = string.ascii_uppercase

def caesarCipher (s,k) :
    result = []
    for i in s :
        if i.isupper() :
            result.append(symbol_high[(symbol_high.index(i)+k) % len(symbol_high)])

        elif i.islower() :
            result.append(symbol_low[(symbol_low.index(i)+k) % len(symbol_low)])

        else:
            result.append(i)

    return "".join(map(str,result))

if __name__=='__main__' :
    s = "sanath"
    k = 1
    print(caesarCipher(s,k))
