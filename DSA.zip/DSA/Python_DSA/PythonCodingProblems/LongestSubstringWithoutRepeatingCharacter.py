def longestUniqueSubsttr(A):
    # last index of every character
    d = {}
    max_len = 0

    # starting index of current
    # window to calculate max_len
    start_idx = 0

    for i in range(0, len(A)):

        # Find the last index of str[i]
        # Update start_idx (starting index of current window)
        # as maximum of current value of start_idx and last
        # index plus 1
        if A[i] in d:
            start_idx = max(start_idx, d[A[i]] + 1)

        # Update result if we get a larger window
        max_len = max(max_len, i - start_idx + 1)

        # Update last index of current char.
        d[A[i]] = i

    return max_len


if __name__=='__main__':
    A = "sanath"
    print(longestUniqueSubsttr(A))

