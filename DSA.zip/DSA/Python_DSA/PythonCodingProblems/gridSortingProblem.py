def gridChallenge (mat) :
    res = 'YES'
    newgrid = []

    for row in mat :
        newgrid.append(sorted(row))

    for a in range(len(mat)) :
        for b in range(a , len(mat[0])) :
            newgrid[a][b] , newgrid[b][a] =  newgrid[b][a] , newgrid[a][b]

    for row in newgrid :
        if row != sorted(row) :
            res = 'NO'
            break

    return res

if __name__=='__main__' :
    mat = ["abk" , "def" , "ghi"]
    print(gridChallenge(mat))


