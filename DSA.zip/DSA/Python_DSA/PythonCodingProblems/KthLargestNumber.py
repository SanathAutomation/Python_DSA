import heapq


def kthLargestNumber (A , k) :
    heapq.heapify(A)
    n = len(A)

    while n > k :
        heapq.heappop(A)
        n -= 1

    return A[0]

if __name__=='__main__' :
    A = [2,4,7,1,9]
    k = 2
    print(kthLargestNumber(A,k))
