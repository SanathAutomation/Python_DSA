from collections import deque

def postfixexp(exp):

    if len(exp) == 0:
        exit(-1)

    stack = deque()

    for ch in exp:
        if ch.isdigit():
            stack.append(int(ch))

        else:
            x = stack.pop()
            y = stack.pop()

            if ch == '+':
                stack.append(y+x)
            elif ch == '-':
                stack.append(y-x)
            elif ch == '*':
                stack.append(y*x)
            else:
                stack.append(y//x)

    return stack.pop()

if __name__=='__main__':
    exp = "1381*+-"
    print(postfixexp(exp))


