def candidateCanAttandAllMeeting (A) :
    A.sort()
    last_end = -1
    for start , end in A :
        if last_end <= start :
            last_end = end

        else:
            return False

    return True

if __name__=='__main__' :
    A = [[7,10],[2,4]]
    print(candidateCanAttandAllMeeting(A))