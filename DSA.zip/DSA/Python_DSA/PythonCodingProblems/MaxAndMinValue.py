arr=[2,4,8,5]

#Finding the max value
max = arr[0]

for i in range(1, len(arr)):
    if (arr[i] > max):
        max = arr[i]
print(max)

#Finding the min value
min = arr[0]

for i in range(1, len(arr)):
    if (arr[i] < min):
        min = arr[i]
print(min)

#find the length of list 1st approach
lelo = [2,4,2,7,9]
print(len(lelo))

#find the length of list 2nd approach
lelo = [2,4,2,7,9]

count = 0
for i in lelo:
    count += 1
print(count)
