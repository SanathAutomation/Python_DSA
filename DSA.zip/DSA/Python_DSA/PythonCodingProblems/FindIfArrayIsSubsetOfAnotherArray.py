#Find if an Array is subset of Another Array using Hashing

def checkSubsetOfArray (arr1 , m , arr2 , n) :
    hashset = set()
    for i in range(m) :
        hashset.add(arr1[i])


    for i in range(n) :
        if arr2[i] in hashset :
            continue
        else:
            return False

    return True

if __name__=='__main__' :
    arr1 = [2,4,6,1,7,9]
    m = len(arr1)

    arr2 = [6,4,9,4]
    n = len(arr2)

    if checkSubsetOfArray(arr1 , m, arr2, n) :
        print("Subset")
    else:
        print("Not subset")
