def reverse_list_by_factor(lst, factor):
    rev = []
    for i in range(0 , len(lst) , factor):
        sublist = lst[i:i+factor]
        rev.append(sublist[::-1])

    return rev

if __name__=='__main__' :
    list1 = [1,2,3,4,5,6,7,8,9]
    f = 2
    print(reverse_list_by_factor(list1,f))





