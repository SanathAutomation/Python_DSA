def timeConversion (s) :
    time = s.split(":")
    if s[-2:] == "PM" :
        if time[0] != "12" :
            time[0] = str(int(time[0]) + 12)

    else:
        if time[0] == "12" :
            time[0] = "00"

    newTime = ":".join(time)
    return str(newTime[:-2])

if __name__=='__main__' :
    s = "1:01:00AM"
    print(timeConversion(s))