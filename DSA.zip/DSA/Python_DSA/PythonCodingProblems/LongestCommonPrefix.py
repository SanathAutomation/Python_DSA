
def longestCommonPrefix(X,Y) :
    i = j = 0
    while i < len(X) and j < len(Y) :
        if X[i] != Y[j] :
            break
        i += 1
        j += 1
    return X[:i]

def findLCP(words) :
    prefix = words[0]
    for s in words :
        prefix = longestCommonPrefix(prefix, s)


    return prefix

if __name__=='__main__':
    words = ["technology" , "technician" , "techie"]
    print(findLCP(words))

