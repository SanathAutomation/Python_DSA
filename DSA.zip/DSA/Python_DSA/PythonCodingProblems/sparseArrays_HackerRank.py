def sparseArrays (stringArray , queries) :
    output = []
    for i in queries :
        output.append(stringArray.count(i))
    return output

if __name__=='__main__' :
    A = ["ab" , "aab" , "ab" , "abc"]
    query = ["ab" , "aab"]
    print(sparseArrays(A , query))