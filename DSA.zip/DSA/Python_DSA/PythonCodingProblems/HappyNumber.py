def happyNumber (n) :
    if n == 0 :
        return 0
    s = set()
    while n != 1 :
        if n in s :
            return False
        s.add(n)
        n = sum([int(i) **2 for i in str(n)]) # pow is represented as **2
    else:
        return True

if __name__=='__main__':
    n = 18
    print(happyNumber(n))


