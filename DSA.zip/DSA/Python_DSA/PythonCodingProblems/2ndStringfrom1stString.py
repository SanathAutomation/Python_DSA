def checkStrings(first , second) :
    freq = {}

    for i in first :
        freq[i] = freq.get(i,0) + 1

    for i in second :
        freq[i] = freq.get(i,0) - 1

        if freq.get(i) < 0 :
            return False

    return True

if __name__=='__main__':
    A = "abcdef"
    B = "adbfg"
    print(checkStrings(A,B))




