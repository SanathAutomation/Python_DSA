from typing import List


def getRow(rowIndex) :
    row = []

    # add first 1
    row.append(1)

    for i in range(rowIndex):


# compute additional numbers in between 1's
# iterate from right to left
        for j in range(i, 0, -1):
            row[j] = row[j - 1] + row[j]

            # add last 1
        row.append(1)

    return row

if __name__=='__main__' :
    row = 6
    print(getRow(row))