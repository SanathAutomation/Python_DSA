Str = "Welcome to Python World"

#reverse word in string

words = Str.split(" ")

rev = words[::-1]
revword = " ".join(rev)
print(revword)